export {default as Dashboard} from './Dashboard';
export {default as Register} from './Register';
export {default as Landing} from './Landing';
export {default as Login} from './Login';
export {default as Error} from './Error';
export {default as CreateJob} from './CreateJob';
export {default as DeleteEdit} from './DeleteEdit'
export {default as Admin} from './Admin'

